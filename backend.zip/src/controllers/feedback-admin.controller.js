const Feedback = require("../models/feedback.model");
const {
  sendTemplateEmail,
} = require("../services/email.service");

const updateFeedbackStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const allowedStatuses = [
      "new",
      "reviewing",
      "resolved",
      "closed",
    ];

    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid feedback status.",
      });
    }

    const feedback = await Feedback.findById(id);

    if (!feedback) {
      return res.status(404).json({
        success: false,
        message: "Feedback not found.",
      });
    }

    const previousStatus = feedback.status;

    feedback.status = status;
    await feedback.save();

    // Send the email only when an issue becomes resolved.
    if (
      feedback.type === "issue" &&
      previousStatus !== "resolved" &&
      status === "resolved"
    ) {
      try {
        const populatedFeedback = await Feedback.findById(id)
          .populate("userId", "name email");

        const user = populatedFeedback?.userId;

        if (!user?.email) {
          throw new Error(
            "The reporting user or their email address was not found."
          );
        }

        const templateId =
          process.env.RESEND_ISSUE_RESOLVED_TEMPLATE_ID;

        await sendTemplateEmail({
          to: user.email,
          templateId,
          variables: {
            username: user.name,
            issueMessage: feedback.message,
          },
        });
      } catch (emailError) {
        console.error(
          "Issue resolution email failed:",
          emailError
        );

        // The issue remains resolved even if email delivery fails.
      }
    }

    return res.status(200).json({
      success: true,
      message: "Feedback status updated successfully.",
      feedback,
    });
  } catch (error) {
    console.error("Update feedback status error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to update feedback status.",
    });
  }
};

module.exports = {
  updateFeedbackStatus,
};