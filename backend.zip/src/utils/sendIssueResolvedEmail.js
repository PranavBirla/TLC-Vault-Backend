const resend = require("../config/resend");

const sendIssueResolvedEmail = async ({
  email,
  username,
  issueMessage,
}) => {
  const templateId =
    process.env.RESEND_ISSUE_RESOLVED_TEMPLATE_ID;

  if (!templateId) {
    throw new Error(
      "RESEND_ISSUE_RESOLVED_TEMPLATE_ID is not configured"
    );
  }

  const { data, error } = await resend.emails.send({
    from: "The Last Commit <support@thelastcommit.xyz>",
    to: [email],

    template: {
      id: templateId,

      variables: {
        username: username || "there",
        issueMessage: issueMessage || "No issue description available.",
      },
    },
  });

  if (error) {
    console.error("Issue resolution email failed:", error);
    throw new Error(error.message);
  }

  console.log(
    "Issue resolution email accepted by Resend:",
    data.id
  );

  return data;
};

module.exports = sendIssueResolvedEmail;